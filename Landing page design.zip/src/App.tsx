type IconName = "arrow" | "bolt" | "people" | "play" | "spark" | "stack"

function Icon({ name, className = "" }: { name: IconName className?: string }) {
  const paths: Record<IconName, React.ReactNode> = {
    arrow: (
      <>
        <path d="M5 12h14" />
        <path d="m13 6 6 6-6 6" />
      </>
    ),
    bolt: <path d="m13 2-9 12h7l-1 8 9-12h-7l1-8Z" />,
    people: (
      <>
        <path d="M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2" />
        <circle cx="9" cy="7" r="4" />
        <path d="M22 21v-2a4 4 0 0 0-3-3.87M16 3.13a4 4 0 0 1 0 7.75" />
      </>
    ),
    play: <path d="m9 7 8 5-8 5V7Z" />,
    spark: (
      <>
        <path d="m12 3 1.35 4.15L17.5 8.5l-4.15 1.35L12 14l-1.35-4.15L6.5 8.5l4.15-1.35L12 3Z" />
        <path d="m18.5 15 .7 2.3 2.3.7-2.3.7-.7 2.3-.7-2.3-2.3-.7 2.3-.7.7-2.3Z" />
      </>
    ),
    stack: (
      <>
        <path d="m12 2 9 5-9 5-9-5 9-5Z" />
        <path d="m3 12 9 5 9-5M3 17l9 5 9-5" />
      </>
    ),
  }

  return (
    <svg
      aria-hidden="true"
      className={className}
      fill="none"
      viewBox="0 0 24 24"
      stroke="currentColor"
      strokeLinecap="round"
      strokeLinejoin="round"
      strokeWidth="1.8"
    >
      {paths[name]}
    </svg>
  )
}

function Brand({ light = false }: { light?: boolean }) {
  return (
    <a
      className={`brand ${light ? "brand--light" : ""}`}
      href="#top"
      aria-label="Morrow home"
    >
      <span className="brand__mark" aria-hidden="true">
        <span />
        <span />
      </span>
      <span>Morrow</span>
    </a>
  )
}

function Button({
  children,
  href,
  tone = "dark",
  icon = true,
}: {
  children: React.ReactNode
  href: string
  tone?: "dark" | "lime" | "light"
  icon?: boolean
}) {
  return (
    <a className={`button button--${tone}`} href={href}>
      <span>{children}</span>
      {icon && (
        <span className="button__icon">
          <Icon name="arrow" />
        </span>
      )}
    </a>
  )
}

const features = [
  {
    number: "01",
    icon: "stack" as const,
    tone: "lime",
    title: "Projects, not lectures.",
    copy: "Build portfolio-ready work through guided, real-world creative briefs.",
  },
  {
    number: "02",
    icon: "people" as const,
    tone: "coral",
    title: "Learn with your people.",
    copy: "Small cohorts, honest feedback, and collaborators who keep you moving.",
  },
  {
    number: "03",
    icon: "bolt" as const,
    tone: "blue",
    title: "Momentum that sticks.",
    copy: "Weekly milestones and expert coaching turn good intentions into progress.",
  },
]

function FeatureCard({ feature }: { feature: typeof features[number] }) {
  return (
    <article className={`feature-card feature-card--${feature.tone}`}>
      <div className="feature-card__top">
        <span className="feature-card__number">{feature.number}</span>
        <span className="feature-card__icon">
          <Icon name={feature.icon} />
        </span>
      </div>
      <div>
        <h3>{feature.title}</h3>
        <p>{feature.copy}</p>
      </div>
    </article>
  )
}

export default function App() {
  return (
    <main id="top">
      <div className="announcement">
        <p>
          Spring cohorts are now open <span aria-hidden="true">↗</span>
        </p>
      </div>

      <header className="site-header shell">
        <Brand />
        <nav aria-label="Primary navigation">
          <a href="#programs">Programs</a>
          <a href="#method">How it works</a>
          <a href="#stories">Student stories</a>
        </nav>
        <Button href="#join" icon={false}>
          Explore programs
        </Button>
      </header>

      <section className="hero shell" aria-labelledby="hero-title">
        <div className="hero__copy">
          <div className="eyebrow">
            <span className="eyebrow__icon">
              <Icon name="spark" />
            </span>
            Learning for creative minds
          </div>
          <h1 id="hero-title">
            Don’t just learn.
            <br />
            <em>Make it real.</em>
          </h1>
          <p className="hero__lede">
            Live, project-based programs that help curious people build
            practical skills, meaningful work, and a career they’re proud of.
          </p>
          <div className="hero__actions">
            <Button href="#programs" tone="lime">
              Find your program
            </Button>
            <a className="text-link" href="#method">
              <span className="text-link__play">
                <Icon name="play" />
              </span>
              See how it works
            </a>
          </div>
          <div className="hero__proof">
            <div className="avatars" aria-hidden="true">
              <span>MK</span>
              <span>JL</span>
              <span>AN</span>
              <span>+</span>
            </div>
            <p>
              <strong>4.9 out of 5</strong>
              <span>from 2,000+ learners</span>
            </p>
          </div>
        </div>

        <div className="hero__visual">
          <div className="hero__image-frame">
            <img
              src="https://images.unsplash.com/photo-1531482615713-2afd69097998?crop=entropy&cs=tinysrgb&fit=crop&fm=jpg&q=85&w=1200"
              alt="Two students collaborating on a digital project at a computer"
            />
          </div>
          <div className="floating-card floating-card--top">
            <span className="floating-card__icon">
              <Icon name="spark" />
            </span>
            <p>
              <strong>12 weeks</strong>
              <span>to your next chapter</span>
            </p>
          </div>
          <div className="floating-card floating-card--bottom">
            <span className="status-dot" />
            <p>
              <strong>Live session</strong>
              <span>Design critique · 6:00 PM</span>
            </p>
          </div>
          <div className="scribble" aria-hidden="true">
            <svg viewBox="0 0 130 70" fill="none">
              <path d="M4 63c21-8 26-31 5-34-18-2-5 35 32 25 30-8 42-25 30-33-16-11-23 25 4 32 19 5 37-8 50-24" />
              <path d="m116 25 10 4-3-11" />
            </svg>
          </div>
        </div>
      </section>

      <section className="logo-strip shell" aria-label="Learning partners">
        <p>Skills built for teams at</p>
        <div>
          <span>Northstar</span>
          <span>Fieldwork</span>
          <span>ACME®</span>
          <span>Plainspace</span>
          <span>orbit</span>
        </div>
      </section>

      <section
        className="features"
        id="programs"
        aria-labelledby="features-title"
      >
        <div className="shell">
          <div className="section-heading">
            <div>
              <span className="kicker">Why Morrow</span>
              <h2 id="features-title">
                Learning designed
                <br />
                for <em>doing.</em>
              </h2>
            </div>
            <p>
              Skip passive playlists. Every Morrow program combines structure,
              community, and practical work to help you grow.
            </p>
          </div>
          <div className="feature-grid" id="method">
            {features.map((feature) => (
              <FeatureCard key={feature.number} feature={feature} />
            ))}
          </div>
        </div>
      </section>

      <section className="cta shell" id="join">
        <div>
          <span className="kicker kicker--light">Your next chapter</span>
          <h2>
            Start making work
            <br />
            that <em>moves you.</em>
          </h2>
        </div>
        <Button href="#programs" tone="lime">
          Explore all programs
        </Button>
      </section>

      <footer id="stories">
        <div className="footer__main shell">
          <div>
            <Brand light />
            <p>Practical learning for curious, creative people.</p>
          </div>
          <div className="footer__links">
            <div>
              <span>Learn</span>
              <a href="#programs">Programs</a>
              <a href="#method">How it works</a>
              <a href="#stories">Stories</a>
            </div>
            <div>
              <span>Connect</span>
              <a href="#join">Instagram</a>
              <a href="#join">LinkedIn</a>
              <a href="mailto:hello@morrow.example">Email us</a>
            </div>
          </div>
        </div>
        <div className="footer__bottom shell">
          <span>© 2025 Morrow Learning Co.</span>
          <span>Made for people in progress.</span>
        </div>
      </footer>
    </main>
  )
}
